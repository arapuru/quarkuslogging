package com.nscorp.fms.logging.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class LogEvent {

  public String timestamp;
  public String loggerName;
  public String level;
  public String tracepoint;
  public String message;

  //public String threadName;
  //public Long threadId;

  public Details details;

  //public String ndc;
  public String hostName;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  public static class Details {
    public String data_entity_type;
    public String flow_name;
    public String target_entity_id;
    public String source_entity_id;
  }
}