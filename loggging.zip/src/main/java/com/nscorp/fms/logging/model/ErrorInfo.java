package com.nscorp.fms.logging.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ErrorInfo {
    public String error_code;
    public String error_message;
    public String error_details;
    public Boolean retryable;
    public String stacktrace;
}
