package com.nscorp.fms.logging.logger;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nscorp.fms.logging.model.ErrorInfo;
import com.nscorp.fms.logging.model.Tracepoint;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.time.OffsetDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

@ApplicationScoped
public class FMSLogger {

  private static final Logger LOG = LoggerFactory.getLogger("com.nscorp.fms");
  private static final int MAX_STACKTRACE_CHARS = 8000;

  @Inject ObjectMapper objectMapper;

  @ConfigProperty(name = "fms.logging.json.enabled", defaultValue = "true")
  boolean structuredJsonEnabled;

  @ConfigProperty(name = "fms.service", defaultValue = "fms")
  String service;

  @ConfigProperty(name = "fms.environment", defaultValue = "dev")
  String environment;

  // ----------------------------
  // Context setters
  // ----------------------------

  public void setCorrelationId(String correlationId) {
    if (correlationId != null && !correlationId.isBlank()) {
      MdcFields.put(MdcFields.CORRELATION_ID, correlationId);
    }
  }

  public void setDetails(String flowName, String dataEntityType, String targetEntityId, String sourceEntityId) {
    if (flowName != null && !flowName.isBlank()) MdcFields.put(MdcFields.FLOW_NAME, flowName);
    if (dataEntityType != null && !dataEntityType.isBlank()) MdcFields.put(MdcFields.DATA_ENTITY_TYPE, dataEntityType);
    if (targetEntityId != null && !targetEntityId.isBlank()) MdcFields.put(MdcFields.TARGET_ENTITY_ID, targetEntityId);
    if (sourceEntityId != null && !sourceEntityId.isBlank()) MdcFields.put(MdcFields.SOURCE_ENTITY_ID, sourceEntityId);
  }

  public void setMetricProcessingTimeMs(Long ms) {
    if (ms != null) MdcFields.put(MdcFields.PROCESSING_TIME_MS, String.valueOf(ms));
  }

  public void setMetricPayloadSizeBytes(Long bytes) {
    if (bytes != null) MdcFields.put(MdcFields.PAYLOAD_SIZE_BYTES, String.valueOf(bytes));
  }

  public void clearContext() {
    MdcFields.clearAll();
  }

  // ----------------------------
  // Public logging APIs
  // ----------------------------

  public void info(String message, Tracepoint tp, Object... args) {
    logEvent("INFO", tp, null, null, message, args);
  }

  public void warn(String message, Tracepoint tp, Object... args) {
    logEvent("WARN", tp, null, null, message, args);
  }

  public void warn(String message, Tracepoint tp, Throwable t, Object... args) {
    logEvent("WARN", tp, t, null, message, args);
  }

  public void debug(String message, Tracepoint tp, Object... args) {
    if (!LOG.isDebugEnabled()) return;
    logEvent("DEBUG", tp, null, null, message, args);
  }

  public void debug(String message, Tracepoint tp) {
    if (!LOG.isDebugEnabled()) return;
    logEvent("DEBUG", tp, null, null, message, new Object[0]);
  }

  public void debug(String message, Tracepoint tp, Throwable t, Object... args) {
    if (!LOG.isDebugEnabled()) return;
    logEvent("DEBUG", tp, t, null, message, args);
  }

  public void debugWithPayload(String message, Tracepoint tp, Object payloadObject, Object... args) {
    if (!LOG.isDebugEnabled()) return;
    logEvent("DEBUG", tp, null, payloadObject, message, args);
  }

  public void error(String message, Throwable t, Object... args) {
    logEvent("ERROR", Tracepoint.ERROR, t, null, message, args);
  }

  public void error(String message, Throwable t, ErrorInfo errorInfo, Object... args) {
    logEvent("ERROR", Tracepoint.ERROR, t, errorInfo, message, args);
  }

  public void error(String message, Throwable t, Map<String, Object> errorMap, Object... args) {
    logEvent("ERROR", Tracepoint.ERROR, t, errorMap, message, args);
  }

  // ----------------------------
  // Single internal implementation
  // ----------------------------

  private void logEvent(String level,
                        Tracepoint tracepoint,
                        Throwable throwable,
                        Object payloadOrError,
                        String messageTemplate,
                        Object[] args) {

    // Ensure message is never null (prevents "{}" / blank surprises)
    String safeTemplate = (messageTemplate == null || messageTemplate.isBlank())
        ? "(no message)"
        : messageTemplate;

    if (!structuredJsonEnabled) {
      logPlain(level, tracepoint, throwable, safeTemplate, args);
      return;
    }

    Map<String, Object> event = new LinkedHashMap<>();
    event.put("timestamp", OffsetDateTime.now().toString());
    event.put("level", level);
    event.put("loggerName", "com.nscorp.fms");
    event.put("tracepoint", tracepoint != null ? tracepoint.name() : null);
    event.put("message", slf4jFormat(safeTemplate, args));
    event.put("environment", environment);
    event.put("service", service);

    String corr = MdcFields.get(MdcFields.CORRELATION_ID);
    if (corr != null && !corr.isBlank()) event.put("correlation_id", corr);

    Map<String, Object> details = buildDetails();
    if (!details.isEmpty()) event.put("details", details);

    Map<String, Object> metrics = buildMetrics();
    if (!metrics.isEmpty()) event.put("metrics", metrics);

    if ("DEBUG".equals(level) && payloadOrError != null) {
      event.put("payload", payloadOrError);
    }

    if (("WARN".equals(level) || "ERROR".equals(level)) && (payloadOrError != null || throwable != null)) {
      event.put("error", buildErrorBlock(payloadOrError, throwable));
    }

    String json = getJson(event);

    switch (level) {
      case "DEBUG" -> LOG.debug(json);
      case "WARN"  -> LOG.warn(json);
      case "ERROR" -> LOG.error(json);
      default      -> LOG.info(json);
    }
  }

  private void logPlain(String level, Tracepoint tp, Throwable t, String msg, Object[] args) {
    String prefixed = (tp != null ? tp.name() + " : " : "") + msg;

    switch (level) {
      case "DEBUG" -> {
        if (t != null && (args == null || args.length == 0)) LOG.debug(prefixed, t);
        else if (t != null) { LOG.debug(prefixed, args); LOG.debug("exception", t); }
        else LOG.debug(prefixed, args);
      }
      case "WARN" -> {
        if (t != null && (args == null || args.length == 0)) LOG.warn(prefixed, t);
        else if (t != null) { LOG.warn(prefixed, args); LOG.warn("exception", t); }
        else LOG.warn(prefixed, args);
      }
      case "ERROR" -> {
        if (t != null && (args == null || args.length == 0)) LOG.error(prefixed, t);
        else if (t != null) { LOG.error(prefixed, args); LOG.error("exception", t); }
        else LOG.error(prefixed, args);
      }
      default -> LOG.info(prefixed, args);
    }
  }

  private Map<String, Object> buildDetails() {
    Map<String, Object> details = new LinkedHashMap<>();
    addIfExists(details, "flow_name", MdcFields.get(MdcFields.FLOW_NAME));
    addIfExists(details, "data_entity_type", MdcFields.get(MdcFields.DATA_ENTITY_TYPE));
    addIfExists(details, "target_entity_id", MdcFields.get(MdcFields.TARGET_ENTITY_ID));
    addIfExists(details, "source_entity_id", MdcFields.get(MdcFields.SOURCE_ENTITY_ID));
    return details;
  }

  private Map<String, Object> buildMetrics() {
    Map<String, Object> metrics = new LinkedHashMap<>();
    addIfExists(metrics, "processing_time_ms", MdcFields.get(MdcFields.PROCESSING_TIME_MS));
    addIfExists(metrics, "payload_size_bytes", MdcFields.get(MdcFields.PAYLOAD_SIZE_BYTES));
    return metrics;
  }

  private Map<String, Object> buildErrorBlock(Object payloadOrError, Throwable t) {
    if (payloadOrError instanceof ErrorInfo ei) {
      Map<String, Object> m = new LinkedHashMap<>();
      m.put("error_code", ei.error_code);
      m.put("error_message", ei.error_message);
      m.put("error_details", ei.error_details);
      m.put("retryable", ei.retryable);
      m.put("stacktrace", ei.stacktrace);
      return m;
    }

    if (payloadOrError instanceof Map<?, ?> map) {
      Map<String, Object> m = new LinkedHashMap<>();
      for (Map.Entry<?, ?> e : map.entrySet()) {
        if (e.getKey() != null) m.put(String.valueOf(e.getKey()), e.getValue());
      }
      if (t != null && !m.containsKey("stacktrace")) m.put("stacktrace", getStackTrace(t));
      return m;
    }

    Map<String, Object> m = new LinkedHashMap<>();
    if (t != null) {
      m.put("error_code", null); // do not fabricate
      m.put("error_message", (t.getMessage() != null && !t.getMessage().isBlank())
          ? t.getMessage()
          : t.getClass().getSimpleName());
      m.put("error_details", t.getClass().getName());
      m.put("retryable", false);
      m.put("stacktrace", getStackTrace(t));
    }
    return m;
  }

  private String getJson(Object o) {
    try {
      return objectMapper.writeValueAsString(o);
    } catch (JsonProcessingException e) {
      return "{\"level\":\"ERROR\",\"message\":\"Failed to serialize log event\",\"error\":\"" + escape(e.toString()) + "\"}";
    }
  }

  private static String slf4jFormat(String template, Object[] args) {
    if (template == null) return null;
    if (args == null || args.length == 0) return template;

    StringBuilder out = new StringBuilder(template.length() + 32);
    int argIndex = 0;

    for (int i = 0; i < template.length(); i++) {
      char c = template.charAt(i);
      if (c == '{' && i + 1 < template.length() && template.charAt(i + 1) == '}' && argIndex < args.length) {
        out.append(String.valueOf(args[argIndex++]));
        i++;
      } else {
        out.append(c);
      }
    }
    return out.toString();
  }

  private static void addIfExists(Map<String, Object> m, String k, String v) {
    if (v != null && !v.isBlank()) m.put(k, v);
  }

  private static String getStackTrace(Throwable t) {
    StringWriter sw = new StringWriter();
    t.printStackTrace(new PrintWriter(sw));
    String s = sw.toString();
    return s.length() > MAX_STACKTRACE_CHARS ? s.substring(0, MAX_STACKTRACE_CHARS) : s;
  }

  private static String escape(String s) {
    return s == null ? "" : s.replace("\"", "\\\"");
  }
}