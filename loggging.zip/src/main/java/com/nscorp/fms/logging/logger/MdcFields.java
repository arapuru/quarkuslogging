package com.nscorp.fms.logging.logger;

import org.slf4j.MDC;

public final class MdcFields {

  private MdcFields() {}

  public static final String CORRELATION_ID = "correlation_id";

  public static final String FLOW_NAME = "details.flow_name";
  public static final String DATA_ENTITY_TYPE = "details.data_entity_type";
  public static final String TARGET_ENTITY_ID = "details.target_entity_id";
  public static final String SOURCE_ENTITY_ID = "details.source_entity_id";

  public static final String PROCESSING_TIME_MS = "metrics.processing_time_ms";
  public static final String PAYLOAD_SIZE_BYTES = "metrics.payload_size_bytes";

  public static void put(String key, String value) {
    if (value == null) return;
    MDC.put(key, value);
  }

  public static String get(String key) {
    return MDC.get(key);
  }

  public static void remove(String key) {
    MDC.remove(key);
  }

  public static void clearAll() {
    MDC.clear();
  }
}