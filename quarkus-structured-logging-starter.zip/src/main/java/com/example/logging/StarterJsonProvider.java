
package com.example.logging;

import io.quarkiverse.loggingjson.JsonGenerator;
import io.quarkiverse.loggingjson.providers.JsonContext;
import io.quarkiverse.loggingjson.providers.JsonContextProvider;
import io.quarkiverse.loggingjson.providers.JsonProvider;
import io.opentelemetry.api.trace.Span;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;

import java.io.IOException;
import java.time.Instant;

@Singleton
public class StarterJsonProvider implements JsonProvider {

    @Inject
    JsonContextProvider contextProvider;

    @Override
    public void writeTo(JsonGenerator jg) throws IOException {

        JsonContext ctx = contextProvider.get();

        jg.writeStringField("timestamp", Instant.now().toString());
        jg.writeStringField("level", ctx.getLevel().name());
        jg.writeStringField("message", ctx.getMessage());

        String correlationId = ctx.getMdcValue("correlation_id");
        if (correlationId != null) {
            jg.writeStringField("correlation_id", correlationId);
        }

        Span span = Span.current();
        if (span != null && span.getSpanContext().isValid()) {
            jg.writeStringField("trace_id", span.getSpanContext().getTraceId());
            jg.writeStringField("span_id", span.getSpanContext().getSpanId());
        }

        ctx.writeStructuredArguments(jg);

        if (ctx.getThrowable() != null) {
            jg.writeStartObject("error");
            jg.writeStringField("type", ctx.getThrowable().getClass().getName());
            jg.writeStringField("message", ctx.getThrowable().getMessage());
            jg.writeEndObject();
        }
    }
}
