
package com.example.logging;

import io.quarkiverse.loggingjson.JsonGenerator;
import io.quarkiverse.loggingjson.providers.StructuredArgument;

import java.io.IOException;
import java.util.Objects;

public final class KeyValueArg implements StructuredArgument {

    private final String key;
    private final Object value;

    private KeyValueArg(String key, Object value) {
        this.key = Objects.requireNonNull(key);
        this.value = value;
    }

    public static StructuredArgument kv(String key, Object value) {
        return new KeyValueArg(key, value);
    }

    @Override
    public void writeTo(JsonGenerator jg) throws IOException {
        if (value == null) {
            jg.writeNullField(key);
        } else {
            jg.writeObjectField(key, value);
        }
    }
}
