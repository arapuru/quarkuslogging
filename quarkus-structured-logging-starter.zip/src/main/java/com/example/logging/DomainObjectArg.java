
package com.example.logging;

import io.quarkiverse.loggingjson.JsonGenerator;
import io.quarkiverse.loggingjson.providers.StructuredArgument;

import java.io.IOException;

public final class DomainObjectArg<T> implements StructuredArgument {

    private final String field;
    private final T value;

    public DomainObjectArg(String field, T value) {
        this.field = field;
        this.value = value;
    }

    @Override
    public void writeTo(JsonGenerator jg) throws IOException {
        if (value != null) {
            jg.writeObjectField(field, value);
        }
    }
}
