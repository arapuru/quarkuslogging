
# Quarkus Structured Logging Starter

A reusable logging starter built on quarkus-logging-json.

## Features
- Latest JsonProvider API
- Domain object structured logging
- OpenTelemetry trace/span auto-enrichment
- Async logging safe

## Usage

log.info(
  "Order created",
  new DomainObjectArg<>("details", order)
);
