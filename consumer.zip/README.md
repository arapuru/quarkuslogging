# dtna-fts-consvc
Consume BOLs from the Kafka topic (published by the DTN service below) and send them to AdaptIQ via REST API for creation
