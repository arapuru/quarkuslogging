package com.nscorp.fms.logging.model;

import io.quarkus.runtime.annotations.RegisterForReflection;

/**
 * Enum containing Different Trace Point Status
 * 
 */
@RegisterForReflection
public enum TraceStatus {
    START,
    IN_PROCESS,
    BEFORE_REQUEST,
    AFTER_REQUEST,
    ERROR,
    END;
}
