package com.nscorp.fms.dtna.service;

import com.nscorp.fms.dtna.util.DateTimeHelper;
import com.nscorp.fms.logging.logger.FMSLogger;
import com.nscorp.fms.logging.model.TraceStatus;
import com.nscorp.fms.dtna.util.JsonHelper;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.json.Json;
import jakarta.json.JsonObject;
import jakarta.json.JsonObjectBuilder;
import jakarta.json.JsonReader;

import java.io.StringReader;


@ApplicationScoped
public class PayloadTransformer {

  @Inject FMSLogger fmsLogger;

  public String transform(String inputPayload) {

    fmsLogger.info("Starting payload transformation.", TraceStatus.IN_PROCESS.name());
    JsonObjectBuilder outputJsonObject = null;
    try {
      JsonReader inputPayloadReader = Json.createReader(new StringReader(inputPayload));
      JsonObject input = inputPayloadReader.readObject();
      // --- REQUIRED FIELDS throw exception if empty or null---
      String docketNumber = JsonHelper.checkIfValueExists("docket_number",input.get("bol_number"));
      String volume = JsonHelper.checkIfValueExists("volume",input.get("gross_gallons"));
      String tempCompValue = JsonHelper.checkIfValueExists("temp_comp_value",input.get("net_gallons"));
      String productCode = JsonHelper.checkIfValueExists("product_code",input.get("product_code"));
      String startLoadDateTime =  JsonHelper.checkIfValueExists( "issued_at",DateTimeHelper.formatDateTime(JsonHelper.asString(input.get("start_load_date")),JsonHelper.asString(input.get("start_load_time"))));
      outputJsonObject = Json.createObjectBuilder();
      outputJsonObject.add("docket_number", JsonHelper.asString(input.get("bol_number")));
      String uom = JsonHelper.asString(input.get("unit_of_measure"));
      if (!uom.isBlank() && uom.equalsIgnoreCase("B"))  
          uom = "bbl";
      else  uom = "gal";
      outputJsonObject.add("docket_number", docketNumber);
      outputJsonObject.add("volume_unit", uom);
      outputJsonObject.add("ambient_volume", volume);
      outputJsonObject.add("temp_comp_volume", tempCompValue);
      outputJsonObject.add("product_code", productCode);
      outputJsonObject.add("purchase_order", JsonHelper.asString(input.get("purchase_number")));
      JsonHelper.addIfExists(outputJsonObject,"temperature", input.get("temperature"));

    //Vehicle Number not needed for Field Trials
      //String vehicleNumber = JsonHelper.asString(input.get("vehicle_number"));
      //JsonHelper.addIfExists(output, "tank_code",vehicleNumber);
      // int daysToAdd = (vehicleNumber != null && !vehicleNumber.isBlank()) ? 180 : 7;
                //output.add( "field_displayable_until",       DateTimeHelper.addDaysToDateString(issuedAt, daysToAdd) );
      
      //JsonHelper.addIfExists(outputJsonObject, "carrier_mapping_code", input.get("carrier_scac"));
      //JsonHelper.addIfExists(outputJsonObject, "terminal_mapping_code", input.get("tcn"));
      //JsonHelper.addIfExists(outputJsonObject, "location_mapping_code", input.get("destination_customer_number"));
      //JsonHelper.addIfExists(outputJsonObject, "supplier_mapping_code", input.get("supplier"));
      //JsonHelper.addIfExists(outputJsonObject, "timezone_mapping_code", input.get("tcn"));

      if (!JsonHelper.isNegative(volume) && !JsonHelper.isNegative(tempCompValue)) {
        outputJsonObject.add("issued_at", startLoadDateTime);
      } else {
        outputJsonObject.add("cancelled", false);
        outputJsonObject.add("cancelled_at", startLoadDateTime);
      }
      outputJsonObject.add("metadata", input);
      String field_displayable_until = DateTimeHelper.addDaysToDateString(startLoadDateTime,7);
      JsonHelper.addIfExists(outputJsonObject,"field_displayable_until", field_displayable_until);

      fmsLogger.debug("Completed payload transformation successfully.", TraceStatus.IN_PROCESS.name());
    } catch (Exception e) {
      fmsLogger.error(
              "Unexpected error during transformation: " + e.getMessage(), TraceStatus.ERROR.name(), e);
    }


    return outputJsonObject.build().toString();

  }
}
