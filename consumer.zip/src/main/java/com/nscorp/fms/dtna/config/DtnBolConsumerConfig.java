package com.nscorp.fms.dtna.config;

import java.util.Set;

import io.smallrye.config.ConfigMapping;
import io.smallrye.config.WithDefault;

@ConfigMapping(prefix = "adaptiq")
public interface DtnBolConsumerConfig {

  Retry retry();

  interface Retry {
    Set<Integer> statuses();

    @WithDefault("5")
    int maxAttempts();

    Backoff backoff();
  }

  interface Backoff {
    @WithDefault("200")
    long minMs();

    @WithDefault("3000")
    long maxMs();

    @WithDefault("0.2")
    double jitter();
  }
}
