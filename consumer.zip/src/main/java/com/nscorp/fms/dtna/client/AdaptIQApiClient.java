package com.nscorp.fms.dtna.client;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

@RegisterRestClient(configKey = "adaptiq")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public interface AdaptIQApiClient {

  @POST
  Response postJson(
      String jsonPayload,
      @HeaderParam("Authorization") String authorization,
      @HeaderParam("x-request-id") String requestId
  );
}