package com.nscorp.fms.dtna.client;

import com.nscorp.fms.dtna.auth.TokenService;
import com.nscorp.fms.dtna.config.DtnBolConsumerConfig;
import com.nscorp.fms.dtna.util.JsonHelper;
import com.nscorp.fms.logging.logger.FMSLogger;
import com.nscorp.fms.logging.model.TraceStatus;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.rest.client.inject.RestClient;

@ApplicationScoped
public class AdaptIQRestClient {

    @Inject TokenService tokenService;
    @Inject FMSLogger fmsLogger;
    @Inject DtnBolConsumerConfig config;

    @Inject
    @RestClient
    AdaptIQApiClient api;

    public String postJson(String bolNumber, String jsonPayload, String requestId) {
        final String logPrefix = "DTN BOL : " + bolNumber + " ";
        String token = tokenService.generateToken(bolNumber);

        //fmsLogger.debug(logPrefix + "Calling AdaptIQ", TraceStatus.BEFORE_REQUEST.name(), jsonPayload);

        try {
            Response resp = api.postJson(jsonPayload, "Bearer " + token, requestId);
            int status = resp.getStatus();
            String body = JsonHelper.getJsonBody(resp);

//            fmsLogger.debug(logPrefix + "AdaptIQ response status=" + status,
//                    TraceStatus.AFTER_REQUEST.name(), body);

            if (status >= 200 && status < 300) {
                return body;
            }

            if (config.retry().statuses().contains(status)) {
                throw new RetryableAdaptIQException(
                        "Retryable AdaptIQ response. status=" + status + " body=" + body
                );
            }

            throw new WebApplicationException(Response.status(status).entity(body).build());

        } catch (WebApplicationException wae) {
            Response errorResponse = wae.getResponse();
            int status = 0;
            String errorMessage = "";
            if(errorResponse !=null) {
            	status = errorResponse.getStatus() ;
            	errorMessage = JsonHelper.getErrorMessage(JsonHelper.getJsonBody(errorResponse));
            }

            if (config.retry().statuses().contains(status)) {
                throw new RetryableAdaptIQException("Retryable AdaptIQ response. status=" + status + " error =" + errorMessage, wae);
            }

            fmsLogger.error(logPrefix + "AdaptIQ REST API error status=" + status + " error = " + errorMessage);

            throw wae;

        } catch (RetryableAdaptIQException rae) {
            fmsLogger.warn(logPrefix + "Retryable AdaptIQ failure reason=" + rae.getMessage(),
                    TraceStatus.ERROR.name());
            throw rae;

        } catch (Exception e) {
            fmsLogger.warn(logPrefix + "AdaptIQ call failed reason=" + e.getMessage(),
                    TraceStatus.ERROR.name());
            throw e;
        }
    }

    public static class RetryableAdaptIQException extends RuntimeException {
        public RetryableAdaptIQException(String message) { super(message); }
        public RetryableAdaptIQException(String message, Throwable cause) { super(message, cause); }
    }
}