package com.nscorp.fms.dtna.util;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Date;

/**
 * Date/time helper utilities.
 *
 * Assumes ISO-8601 offset date-time strings, e.g.:
 *   2026-01-27T20:48:13-06:00  or  2026-01-28T02:48:13Z
 */
public final class DateTimeHelper {


    private DateTimeHelper() {
        // utility class
    }

    public static String addDaysToDateString(String inputDate, int days) {
        if (inputDate == null || inputDate.isBlank()) {
            return "";
        }

        DateTimeFormatter inputFmt = DateTimeFormatter.ofPattern("MMddyyyy");
        DateTimeFormatter outputFmt = DateTimeFormatter.ISO_LOCAL_DATE;

        try {
            LocalDate date = LocalDate.parse(inputDate.trim(), inputFmt);
            LocalDate finalDate = date.plusDays(days);
            if (finalDate.isBefore(LocalDate.now())) {
                return "";
            }
            return finalDate.format(outputFmt);
        } catch (DateTimeParseException e) {
            return "";
        }
    }
    public static String formatDateTime(String inputDate, String inputTime) {
        if (inputDate == null || inputDate.isBlank()) {
            return "";
        }

        DateTimeFormatter dateFmt = DateTimeFormatter.ofPattern("MMddyyyy");
        DateTimeFormatter timeFmt = DateTimeFormatter.ofPattern("HHmm");
        DateTimeFormatter outputFmt = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");

        try {
            LocalDate date = LocalDate.parse(inputDate.trim(), dateFmt);

            LocalTime time;
            if (inputTime != null && !inputTime.isBlank()) {
                time = LocalTime.parse(inputTime.trim(), timeFmt);
            } else {
                time = LocalTime.MIDNIGHT; // default if time missing
            }

            LocalDateTime dateTime = LocalDateTime.of(date, time);
            return dateTime.format(outputFmt);

        } catch (DateTimeParseException e) {
            return "";
        }
    }

}
