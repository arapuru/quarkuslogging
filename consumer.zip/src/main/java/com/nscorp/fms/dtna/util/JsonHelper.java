package com.nscorp.fms.dtna.util;

import jakarta.json.*;
import jakarta.ws.rs.core.Response;

import java.io.StringReader;
import java.math.BigDecimal;
import java.util.Map;

/**
 * JSON utility helpers.
 */
public final class JsonHelper {

	private JsonHelper() {
		// utility class
	}


	public static String asString(JsonValue value) {
		if (value == null || value == JsonValue.NULL) {
			return "";
		}
		if (value instanceof JsonString js) {
			return js.getString();
		}
		if (value instanceof JsonNumber jn) {
			return jn.toString();
		}
		// fallback (objects/arrays) -> toString()
		return value.toString();
	}
	public static boolean isNegative(String value) {

		if (value == null || value.isBlank() || value.equalsIgnoreCase("null")) {
			return false; // or throw exception depending on your rules
		}
		BigDecimal bd = new BigDecimal(value.trim());
		return bd.signum() < 0;
	}
	
	public static String getJsonBody(Response resp) {
	    try {
	      if (resp == null || !resp.hasEntity()) {
	        return null;
	      }
	      return resp.readEntity(String.class);
	    } catch (Exception e) {
	      return null;
	    }
	  }
	public static String getIdFromBody(String json) {
        try (JsonReader reader = Json.createReader(new StringReader(json))) {
            JsonObject obj = reader.readObject();
            if (!obj.containsKey("id") || obj.isNull("id")) {
                return "";
            }
            JsonValue idValue = obj.get("id");
            return asString(idValue);
        } catch (Exception e) {
            return "";
        }
    }
	
	public static String checkIfValueExists(String fieldName, JsonValue value) {
	    String s = asString(value);
	    if (s ==null || s.isBlank() || s.isEmpty()) {
	      throw new IllegalArgumentException("Missing/empty required field: " + fieldName);
	    }
	    return s;
	  }
	public static String checkIfValueExists(String fieldName, String value) {
	    if (value ==null || value.isBlank() || value.isEmpty()) {
	      throw new IllegalArgumentException("Missing/empty required field: " + fieldName);
	    }
	    return value;
	  }

	public static void addIfExists(JsonObjectBuilder builder, String fieldName, JsonValue value) {
		String s = asString(value);
	    if (s!=null && !s.isBlank() && !s.isEmpty()) {
	      builder.add(fieldName, value);
	    }
	  }
	public static void addIfExists(JsonObjectBuilder builder, String fieldName, String value) {
	    if (value!=null && !value.isBlank() && !value.isEmpty()) {
	      builder.add(fieldName, value);
	    }
	  }
	
	public static String getErrorMessage(String jsonBody) {
        if (jsonBody == null || jsonBody.isBlank()) {
            return "";
        }

        try (JsonReader reader = Json.createReader(new StringReader(jsonBody))) {
            JsonObject jsonObject = reader.readObject();

            if (jsonObject.containsKey("error") && !jsonObject.isNull("error")) {
                return jsonObject.getString("error");
            }

        } catch (Exception e) {
            return "";
        }

        return "";
    }
}
