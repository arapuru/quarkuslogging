package com.nscorp.fms.dtna.constants;

import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;

public final class ConsumerSvcConstants {

  public static final String AUTHORIZATION = "Authorization";
  public static final String SITE_ID = "siteId";
  public static final String UPDATED_FROM = "updatedFrom";
  public static final String ADAPTIQ = "adaptiq";
  public static final String ADAPTIQ_ENDPOINT_URL = "adaptiq.rest.endpoint.url";

  public static final String HEADER_SCHEDULER_TYPE = "schedulerType";
  public static final String HEADER_PUBLISHING_TIMESTAMP = "publishing-timestamp";

  public static final DateTimeFormatter TIMESTAMP_FORMATTER =
      DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss").withZone(ZoneOffset.UTC);

  public static final DateTimeFormatter INPUT_DATE_FORMAT = DateTimeFormatter.ofPattern("MMddyyyy");
  public static final DateTimeFormatter INPUT_TIME_FORMAT = DateTimeFormatter.ofPattern("HHmm");
  public static final DateTimeFormatter OUTPUT_ISO_FORMAT = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
}
