package com.nscorp.fms.dtna.service;

import com.nscorp.fms.dtna.client.AdaptIQRestClient;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.WebApplicationException;

import org.eclipse.microprofile.faulttolerance.CircuitBreaker;
import org.eclipse.microprofile.faulttolerance.Retry;

@ApplicationScoped
public class DtnBolProcessor {

    @Inject AdaptIQRestClient adaptIQRestClient;

    /**
     * Fault-tolerance boundary.
     *
     * - Retry only for RetryableAdaptIQException (raised only for configured statuses).
     * - Abort on WebApplicationException (non-retryable errors), and propagate raw body.
     *
     * maxAttempts = config.retry.maxAttempts()
     * MP FT uses maxRetries (retries after first attempt) => maxRetries = maxAttempts - 1
     */
    @Retry(
            retryOn = AdaptIQRestClient.RetryableAdaptIQException.class,
            abortOn = WebApplicationException.class
    )
    @CircuitBreaker(
            failOn = AdaptIQRestClient.RetryableAdaptIQException.class,
            skipOn = WebApplicationException.class
    )
    public String sendToAdaptIQ(String bolNumber, String payload, String correlationId) {
        return adaptIQRestClient.postJson(bolNumber, payload, correlationId);
    }
}