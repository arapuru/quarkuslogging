package com.nscorp.fms.dtna.auth;

import com.nscorp.fms.logging.logger.FMSLogger;
import com.nscorp.fms.logging.model.TraceStatus;
import io.quarkus.oidc.client.NamedOidcClient;
import io.quarkus.oidc.client.OidcClient;
import io.quarkus.oidc.client.Tokens;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class TokenService {

	@Inject
	@NamedOidcClient("adaptiq")
	OidcClient oidcClient;

	@Inject
	FMSLogger fmsLogger;
	public String generateToken(String bolNumber) {
		final String logPrefix = "DTN BOL : " + bolNumber + " ";
		fmsLogger.info(logPrefix + "Starting token generation process.", TraceStatus.IN_PROCESS.name());
		try {
			Tokens tokens = oidcClient.getTokens().await().indefinitely(); 
			String accessToken = tokens.getAccessToken();
			fmsLogger.info(logPrefix + "Token received from OIDC provider", TraceStatus.IN_PROCESS.name());
			return accessToken;

		} catch (Exception e) {
			fmsLogger.warn(logPrefix + "Token request failed - Error: " + e.getMessage(),TraceStatus.IN_PROCESS.name());
			throw new RuntimeException("AdaptIQ Token request failed. Error: " + e.getMessage(),e);
		}
	}
}