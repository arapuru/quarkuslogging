package com.nscorp.fms.dtna.service;

import java.nio.charset.StandardCharsets;
import java.util.Optional;

import org.apache.kafka.common.header.Header;
import org.apache.kafka.common.header.Headers;
import org.eclipse.microprofile.reactive.messaging.Incoming;
import org.jboss.logging.MDC;

import com.nscorp.fms.dtna.util.JsonHelper;
import com.nscorp.fms.logging.logger.FMSLogger;
import com.nscorp.fms.logging.model.TraceStatus;

import io.smallrye.common.annotation.Blocking;
import io.smallrye.mutiny.Uni;
import io.smallrye.reactive.messaging.kafka.KafkaRecord;
import io.smallrye.reactive.messaging.kafka.api.IncomingKafkaRecordMetadata;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class DtnBolConsumer {

    @Inject FMSLogger fmsLogger;
    @Inject PayloadTransformer transformer;
    @Inject DtnBolProcessor processor; // <-- FT boundary bean

    @Incoming("kafka-consumer")
    @Blocking
    public Uni<Void> consume(KafkaRecord<String, String> message) {
        String bolNumber = message.getKey();
        String topic = message.getTopic();
        int partition = -1;
        long offset = -1;
        String correlationId = "UNKNOWN";

        Optional<IncomingKafkaRecordMetadata> metadata = message.getMetadata(IncomingKafkaRecordMetadata.class);

        if (metadata.isPresent()) {
            IncomingKafkaRecordMetadata meta = metadata.get();
            partition = meta.getPartition();
            offset = meta.getOffset();

            Headers headers = meta.getHeaders();
            if (headers != null) {
                Header h = headers.lastHeader("CORRELATION_ID");
                if (h != null && h.value() != null) {
                    correlationId = new String(h.value(), StandardCharsets.UTF_8);
                }
            }
        }

        final String logPrefix = "DTN BOL : " + bolNumber + " ";
        MDC.put("correlation_id", correlationId);

        try {
            fmsLogger.info(logPrefix + "received from topic=" + topic, TraceStatus.START.name());
            fmsLogger.debug(
                    logPrefix + "metadata partition=" + partition + " offset=" + offset + " correlationId=" + correlationId,
                    TraceStatus.IN_PROCESS.name(),
                    null
            );

            String input = message.getPayload();
            if (input == null || input.isBlank()) {
                IllegalArgumentException ex = new IllegalArgumentException("Payload is null or empty");
                fmsLogger.error(logPrefix + "Empty payload; acknowledging the message", TraceStatus.ERROR.name(), ex);
                return Uni.createFrom().completionStage(message.nack(ex));
            }

            String adaptIQPayload = transformer.transform(input);
            String adaptIQResponseBody = processor.sendToAdaptIQ(bolNumber, adaptIQPayload, correlationId);
            String id = JsonHelper.getIdFromBody(adaptIQResponseBody);
            fmsLogger.info(logPrefix + "successfully created in FTS with id=" + id, TraceStatus.END.name());

            return Uni.createFrom().completionStage(message.ack());

        } catch (Exception e) {
            fmsLogger.error(logPrefix + "processing failed; acknowledging the message", TraceStatus.END.name(), e);
            return Uni.createFrom().completionStage(message.ack());
        } finally {
            MDC.clear();
        }
    }
}