This is readme file for dtna-fts-pubsrv service



