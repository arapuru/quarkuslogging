package com.nscorp.fms.logging.model;

/**
 * Enum containing Different Trace Point Status
 * 
 */
public enum TracePoint {
    START,
    IN_PROCESS,
    BEFORE_REQUEST,
    AFTER_REQUEST,
    ERROR,
    END;
}
