
package com.nscorp.fms.logging.logger;

import java.io.IOException;

import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.jboss.logging.MDC;
import org.jboss.logmanager.ExtLogRecord;

import io.quarkiverse.loggingjson.JsonGenerator;
import io.quarkiverse.loggingjson.JsonProvider;

/**
 * A custom JSON provider for the Quarkus logging framework that injects global 
 * metadata into every log record.
 * <p>
 * This provider ensures that standard Datadog-friendly attributes such as 
 * {@code service}, {@code service_version}, and {@code environment} are 
 * automatically included in the JSON output, alongside the {@code correlation_id} 
 * retrieved from the Mapped Diagnostic Context (MDC).
 * </p>
 */
public class FMSLogDataJsonProvider implements JsonProvider {

	 /**
     * The version of the application, injected from {@code quarkus.application.version}.
     */
    @ConfigProperty(name = "quarkus.application.version", defaultValue = "1.0.0")
    String version;

    /**
     * The active deployment profile (e.g., dev, prod, test), 
     * injected from {@code quarkus.profile}.
     */
    @ConfigProperty(name = "quarkus.profile", defaultValue = "dev")
    String environment;

    /**
     * The name of the service, injected from {@code quarkus.application.name}.
     */
    @ConfigProperty(name = "quarkus.application.name", defaultValue = "")
    String service;


    /**
     * Writes metadata fields to the JSON generator for the current log event.
     * <p>
     * This method enriches the log entry with application identifiers and 
     * extracts the {@code correlation_id} from the MDC to ensure end-to-end 
     * request traceability in Datadog.
     * </p>
     *
     * @param generator The {@link JsonGenerator} used to append fields to the JSON log.
     * @param event     The {@link ExtLogRecord} representing the current log event.
     * @throws IOException If there is an error writing to the JSON stream.
     */
    @Override
    public void writeTo(JsonGenerator generator, ExtLogRecord event) throws IOException {
        generator.writeStringField("service", service);
        generator.writeStringField("version", version);
        generator.writeStringField("environment", environment);
        Object correlationIdObj = MDC.get("correlation_id");
        String correlationId = correlationIdObj != null ? correlationIdObj.toString() : "N/A";
        generator.writeStringField("correlation_id", correlationId);
    }
}
