package com.nscorp.fms.logging.logger;

import java.io.IOException;
import java.util.Map;

import com.nscorp.fms.logging.model.LogError;
import com.nscorp.fms.logging.model.LogMetrics;

import io.quarkiverse.loggingjson.JsonGenerator;
import io.quarkiverse.loggingjson.providers.StructuredArgument;

/**
 * Provides a structured container for log metadata, facilitating consistent 
 * logging patterns across the FMS application.
 * <p>
 * This class implements {@link StructuredArgument}, allowing logging frameworks 
 * to serialize its fields into JSON format for ingestion by platforms like Datadog. 
 * </p>
 */
public class FMSLogEventArgument implements StructuredArgument {

    private String tracepoint;
    private Object payload;
    private Map<?, ?> details;
    private LogError error;
    private LogMetrics metrics;


    public String getTracepoint() {
        return tracepoint;
    }

    public void setTracepoint(String tracepoint) {
        this.tracepoint = tracepoint;
    }

    public Object getPayload() {
        return payload;
    }

    public void setPayload(Object payload) {
        this.payload = payload;
    }

    public Map<?, ?> getDetails() {
        return details;
    }

    public void setDetails(Map<?, ?> details) {
        this.details = details;
    }

    public LogError getError() {
        return error;
    }

    public void setError(LogError error) {
        this.error = error;
    }

    public LogMetrics getMetrics() {
        return metrics;
    }

    public void setMetrics(LogMetrics metrics) {
        this.metrics = metrics;
    }


    /**
     * Serializes the structured log event arguments into a JSON format using the provided generator.
     * <p>
     * This method is typically invoked automatically by the logging framework's 
     * JSON encoder when the {@code FMSLogEventArgument} instance is passed to a logger call. 
     * It ensures that only non-null fields are included in the final JSON output, 
     * producing clean and sparse log entries.
     * </p>
     *
     * @param generator The {@link JsonGenerator} used to write the JSON fields.
     * @throws IOException If an error occurs during the writing process to the underlying output stream.
     */
    @Override
    public void writeTo(JsonGenerator generator) throws IOException {
        generator.writeStringField("tracepoint", tracepoint);

        if(payload!=null){
            generator.writeObjectField("payload", payload);
        }
        if(error!=null){
            generator.writeObjectField("error", error);
        }
        if(details!=null){
            generator.writeObjectField("details", details);
        }
        if(metrics!=null){
            generator.writeObjectField("metrics", metrics);
        }


    }
}
