package com.nscorp.fms.logging.exception;

/**
 * Custom exception class for FMS related errors.
 * Extends {@link RuntimeException} to provide a flexible way to handle various application faults,
 * including specific error codes, retryability flags, and detailed messages.
 */
public class FMSException extends RuntimeException {
    /**
     * A unique code representing the specific type of error that occurred.
     */
    private String errorCode;
    /**
     * A concise, human-readable summary of the error.
     */
    private String errorMessage;
    /**
     * Detailed information about the error, potentially including stack traces or diagnostic info.
     */
    private String errorDetails;
    /**
     * A flag indicating whether the operation that caused the exception might succeed if retried.
     */
    private boolean retryable;
    /**
     * The original underlying cause of the exception, if any.
     */
    private Throwable throwable;

    /**
     * Gets the error code.
     * @return The unique error code.
     */
    public String getErrorCode() {
        return errorCode;
    }

    /**
     * Sets the error code.
     * @param errorCode The unique error code to set.
     */
    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    /**
     * Gets the error message summary.
     * @return The error message.
     */
    public String getErrorMessage() {
        return errorMessage;
    }

    /**
     * Sets the error message summary.
     * @param errorMessage The error message to set.
     */
    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    /**
     * Gets the detailed error information.
     * @return The error details.
     */
    public String getErrorDetails() {
        return errorDetails;
    }

    /**
     * Sets the detailed error information.
     * @param errorDetails The error details to set.
     */
    public void setErrorDetails(String errorDetails) {
        this.errorDetails = errorDetails;
    }

    /**
     * Checks if the exception indicates a retryable operation.
     * @return {@code true} if the operation is retryable, {@code false} otherwise.
     */
    public boolean isRetryable() {
        return retryable;
    }

    /**
     * Sets the retryable flag.
     * @param retryable The retryable status to set.
     */
    public void setRetryable(boolean retryable) {
        this.retryable = retryable;
    }

    /**
     * Gets the underlying cause of this exception.
     * @return The original {@link Throwable} cause.
     */
    public Throwable getThrowable() {
        return throwable;
    }

    /**
     * Sets the underlying cause of this exception.
     * @param throwable The original {@link Throwable} cause to set.
     */
    public void setThrowable(Throwable throwable) {
        this.throwable = throwable;
    }


    /**
     * Constructs a new FMSException with the specified error message.
     * @param errorMessage A concise summary of the error.
     */
    public FMSException(String errorMessage) {
        super(errorMessage);
        this.errorMessage = errorMessage;
    }

    /**
     * Constructs a new FMSException with the specified error message and cause.
     * @param errorMessage A concise summary of the error.
     * @param cause The cause (which is saved for later retrieval by the {@link #getCause()} method).
     */
    public FMSException(String errorMessage, Throwable cause) {
        super(errorMessage, cause);
        this.errorMessage = errorMessage;
        this.throwable = cause;
    }

    /**
     * Constructs a new FMSException with an error code, message, and details.
     * The exception is considered non-retryable by default.
     * @param errorCode A unique code for the error.
     * @param errorMessage A concise summary of the error.
     * @param errorDetails Detailed information about the error.
     */
    public FMSException(String errorCode, String errorMessage, String errorDetails) {
        super(errorMessage);
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
        this.errorDetails = errorDetails;
    }

    /**
     * Constructs a new FMSException with an error code, message, details, and retryability flag.
     * @param errorCode A unique code for the error.
     * @param errorMessage A concise summary of the error.
     * @param errorDetails Detailed information about the error.
     * @param retryable A flag indicating if the operation can be retried.
     */
    public FMSException(String errorCode, String errorMessage, String errorDetails, boolean retryable) {
        super(errorMessage);
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
        this.errorDetails = errorDetails;
        this.retryable = retryable;
    }

    /**
     * Constructs a new FMSException with all details, including an underlying cause.
     * @param errorCode A unique code for the error.
     * @param errorMessage A concise summary of the error.
     * @param errorDetails Detailed information about the error.
     * @param retryable A flag indicating if the operation can be retried.
     * @param cause The cause (which is saved for later retrieval by the {@link #getCause()} method).
     */
    public FMSException(String errorCode, String errorMessage, String errorDetails, boolean retryable,
                        Throwable cause) {
        super(errorMessage, cause);
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
        this.errorDetails = errorDetails;
        this.retryable = retryable;
        this.throwable = cause;
    }
}
