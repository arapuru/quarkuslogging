package com.nscorp.fms.logging.logger;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Map;

import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.jboss.logging.Logger;

import com.nscorp.fms.logging.exception.FMSException;
import com.nscorp.fms.logging.model.LogError;
import com.nscorp.fms.logging.model.TracePoint;

import jakarta.enterprise.context.ApplicationScoped;

/**
 * A custom logging utility class for the FMS application, providing standardized methods
 * for various log levels (INFO, WARN, DEBUG, ERROR).
 * It serializes structured log events and integrates with JBoss Logging, including handling
 * custom {@link FMSException} details and metrics.
 */
@ApplicationScoped
public class FMSLogger {

    /**
     * The underlying JBoss Logger instance used for logging operations.
     */
    private static final Logger logger = Logger.getLogger(FMSLogger.class);

    /**
     * Configuration property to control whether stack traces are included in error logs.
     * Injected via MicroProfile Config.
     */
    @ConfigProperty(name = "app.logging.logstacktrace", defaultValue = "true")
    boolean logStackTrace;


    /**
     * Logs an INFO message with minimal detail.
     * @param message The main log message.
     */
    public void info(String message) {
        log("INFO", message, null, null, null, null);
    }

    /**
     * Logs an INFO message with a specific tracepoint marker.
     * @param message The main log message.
     * @param tracepoint A specific identifier for tracing the application flow.
     */
    public void info(String message, TracePoint tracepoint) {
        log("INFO", message, tracepoint, null, null, null);
    }

    /**
     * Logs an INFO message including a tracepoint and an associated payload object.
     * @param message The main log message.
     * @param tracepoint A specific identifier for tracing the application flow.
     * @param payload An arbitrary object whose size will be captured in logging metrics, and object logged as part of structured event.
     */
    public void info(String message, TracePoint tracepoint, Object payload) {
        log("INFO", message, tracepoint, null, payload, null);
    }

    /**
     * Logs an INFO message with additional key-value details.
     * @param message The main log message.
     * @param details A map of supplementary details to log.
     */
    public void info(String message, Map<String, String> details) {
        log("INFO", message, null, details, null, null);
    }

    /**
     * Logs an INFO message with both a tracepoint and additional details.
     * @param message The main log message.
     * @param tracepoint A specific identifier for tracing the application flow.
     * @param details A map of supplementary details to log.
     */
    public void info(String message, TracePoint tracepoint, Map<String, String> details) {
        log("INFO", message, tracepoint, details, null, null);
    }

    /**
     * Logs a WARN message with minimal detail.
     * @param message The main log message.
     */
    public void warn(String message) {
        log("WARN", message, null, null, null, null);
    }

    /**
     * Logs a WARN message with a specific tracepoint marker.
     * @param message The main log message.
     * @param tracepoint A specific identifier for tracing the application flow.
     */
    public void warn(String message,TracePoint tracepoint) {
        log("WARN", message, tracepoint, null, null, null);
    }

    /**
     * Logs a DEBUG message with minimal detail.
     * @param message The main log message.
     */
    public void debug(String message) {
        log("DEBUG", message, null, null, null, null);
    }

    /**
     * Logs a DEBUG message with a specific tracepoint marker.
     * @param message The main log message.
     * @param tracepoint A specific identifier for tracing the application flow.
     */
    public void debug(String message, TracePoint tracepoint) {
        log("DEBUG", message, tracepoint, null, null, null);
    }

    /**
     * Logs a DEBUG message including a tracepoint and an associated payload object.
     * The payload is included in the log output for DEBUG level.
     * @param message The main log message.
     * @param tracepoint A specific identifier for tracing the application flow.
     * @param payload The payload object to be logged.
     */
    public void debug(String message,TracePoint tracepoint, Object payload) {
        log("DEBUG", message, tracepoint, null, payload, null);
    }

    /**
     * Logs a DEBUG message including a tracepoint and an associated throwable.
     * @param message The main log message.
     * @param tracepoint A specific identifier for tracing the application flow.
     * @param throwable The exception or error associated with the log event.
     */
    public void debug(String message,TracePoint tracepoint, Throwable throwable) {
        log("DEBUG", message, tracepoint, null, null, throwable);
    }

    /**
     * Logs an ERROR message with minimal detail.
     * @param message The main log message.
     */
    public void error(String message) {
        log("ERROR", message, null, null, null, null);
    }

    /**
     * Logs an ERROR message with an associated throwable.
     * @param message The main log message.
     * @param t The exception or error associated with the log event.
     */
    public void error(String message, Throwable t) {
        log("ERROR", message, null, null, null, t);
    }


    /**
     * Logs an ERROR message with a tracepoint and an associated throwable.
     * @param message The main log message.
     * @param tracepoint A specific identifier for tracing the application flow.
     * @param t The exception or error associated with the log event.
     */
    public void error(String message, TracePoint tracepoint, Throwable t) {
        log("ERROR", message, tracepoint, null, null, t);
    }

    /**
     * Logs an ERROR message with all available details: tracepoint, supplementary details, and a throwable.
     * @param message The main log message.
     * @param tracepoint A specific identifier for tracing the application flow.
     * @param details A map of supplementary details to log.
     * @param throwable The exception or error associated with the log event.
     */
    public void error(String message, TracePoint tracepoint, Map<String, String> details, Throwable throwable) {
        log("ERROR", message, tracepoint, details, null, throwable);
    }

    /**
     * The internal core logging mechanism that standardizes log event creation,
     * metric calculation, and error processing before delegation to the underlying logger.
     * @param level The log level (e.g., "INFO", "WARN", "ERROR", "DEBUG").
     * @param message The main log message.
     * @param tracepoint A specific identifier for tracing the application flow.
     * @param details A map of supplementary details to log.
     * @param payload An arbitrary object payload (used for size metrics and included in structured log).
     * @param throwable The exception or error associated with the log event.
     */
    private void log(String level, String message, TracePoint tracepoint, Map<String, String> details, Object payload, Throwable throwable) {
        FMSLogEventArgument fMSLogEventArgument = new FMSLogEventArgument();
        fMSLogEventArgument.setTracepoint(tracepoint!=null?tracepoint.name():"");
        fMSLogEventArgument.setDetails(details);
        
        // Payload is always set on the argument for consistency
        fMSLogEventArgument.setPayload(payload);

        // Populate LogError Object if exception occurs
        if (throwable != null) {
            LogError logError = new LogError();
            if (throwable instanceof FMSException fmsException) {
                logError.setError_code(fmsException.getErrorCode());
                logError.setError_details(fmsException.getErrorDetails());
                logError.setError_message(fmsException.getErrorMessage());
                logError.setRetryable(fmsException.isRetryable());
            }

            if(logStackTrace) {
                // Capture stack trace
                StringWriter stringWriter = new StringWriter();
                PrintWriter printWriter = new PrintWriter(stringWriter);
                throwable.printStackTrace(printWriter);
                logError.setStackTrace(stringWriter.toString());
            }

            fMSLogEventArgument.setError(logError);
        }
        

        logToTarget(level,message,fMSLogEventArgument);
    }

    /**
     * Delegates the final structured log event to the appropriate method of the underlying JBoss Logger
     * based on the provided log level.
     * @param level The log level (e.g., "INFO", "WARN", "ERROR", "DEBUG").
     * @param message The main log message.
     * @param fMSLogEventArgument The structured log event argument containing all details, metrics, and errors.
     */
    private void logToTarget(String level, String message, FMSLogEventArgument fMSLogEventArgument) {

        switch (level) {
            case "WARN" -> logger.warnv(message, fMSLogEventArgument);
            case "ERROR" -> logger.errorv(message, fMSLogEventArgument);
            case "DEBUG" -> logger.debugv(message, fMSLogEventArgument);
            default -> logger.infov(message, fMSLogEventArgument);
        }

    }
}
