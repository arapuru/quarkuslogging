package com.nscorp.fms.dtnbolservice.processor;

import org.jboss.logging.MDC;

import com.nscorp.fms.dtnbolservice.service.DTNBOLCSVProcessor;
import com.nscorp.fms.dtnbolservice.service.DTNS3Service;
import com.nscorp.fms.dtnbolservice.service.SFTPCSVDownloadService;
import com.nscorp.fms.logging.exception.FMSException;
import com.nscorp.fms.logging.logger.FMSLogger;
import com.nscorp.fms.logging.model.TracePoint;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

/**
 * This class is meant for processing MQ message and process validation and
 * publish to kafka and uploading invalid data to S3 bucket
 *
 */
@ApplicationScoped
public class DTNBolProcessor {


	@Inject
	FMSLogger fmsLogger;
	
	@Inject 
	SFTPCSVDownloadService sftpcsvDownloadService;
	
	@Inject 
	DTNBOLCSVProcessor dtnbolcsvProcessor;
	
	@Inject
	DTNS3Service dtns3Service;


	/**
	 * A description will do below thins.
	 * <p>
	 * <ul>
	 * <li>Identify filename from the queue.</li>
	 * <li>Connecting to SFTP and get content into list of CSVRecord Objects</li>
	 * <li>Calls the Validator and get map of valid and invalid Object and from
	 * DTLBoLRecords</li>
	 * <li>Publish Valid message to Kafka.</li>
	 * <li>Upload InValid message to S3 Subject</li>
	 * </ul>
	 * <p>
	 * The rest of the documentation continues here.
	 *
	 * @param queueMsg  String message
	 * @param messageId JMSMessageId
	 */
	public void process(String queueMsg, String messageId) {
		String [] messageArray = queueMsg.split(";");
		String filename = messageArray[0];
		String filepath = messageArray[1];
		try {
			String[] messageIdArray = messageId != null ? messageId.split(":") : null;
			String messageIdValue = messageIdArray[1];
			if (messageIdArray != null) {
				MDC.put("correlation_id", messageIdValue);
			}
			// Processing Message which contains csv only
			if (queueMsg != null && queueMsg.toLowerCase().contains(".csv")) {
				 fmsLogger.info(String.format("DTNA Publisher : Connecting SFTP Server and  Fetching Data with FileName :  %s  From Path Id : %s", filename, filepath), TracePoint.IN_PROCESS);
				byte[] csvBytes =  sftpcsvDownloadService.downloadCsvAsBytes(filepath+"/"+ filename);
				
				if(csvBytes!=null && csvBytes.length>0) {
					boolean status = dtns3Service.upload(filename, csvBytes);
					if(status) {
						dtnbolcsvProcessor.process(csvBytes, messageIdValue,filename);
						//Delete File After Processing
						dtns3Service.deleteFile(filename);
					}
					else {
						fmsLogger.info(String.format("DTNA Publisher : File already processed with FileName :  %s  From Path  : %s", filename, filepath), TracePoint.IN_PROCESS);
					}
				}
				else {
					fmsLogger.info(String.format("DTNA Publisher : Content is empty with FileName :  %s  From Path %s", filename, filepath), TracePoint.IN_PROCESS);
				}
			} else {
				fmsLogger.info(String.format("DTNA Publisher : Received MQ message not containing  CSV Message :  %s ", queueMsg), TracePoint.IN_PROCESS);
			}

		} catch (FMSException e) {
			 fmsLogger.error(String.format("DTNA Publisher : Exception during Processing"), TracePoint.END,e);
			//Deleting file which is already processed
			dtns3Service.deleteFile(filename);
		}
		finally {
			MDC.clear();
		}

	}
}
