package com.nscorp.fms.dtnbolservice.listener;

import com.ibm.mq.jakarta.jms.MQConnectionFactory;
import jakarta.inject.Inject;
import org.eclipse.microprofile.config.inject.ConfigProperty;

import com.ibm.msg.client.jakarta.wmq.WMQConstants;
import com.nscorp.fms.logging.logger.FMSLogger;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.inject.Produces;
import jakarta.jms.ConnectionFactory;

/**
 * This class will be helpful for creating JMS connection Factory 
 * class will be used smallrye-jms for consuming messages
 * 
 */
@ApplicationScoped
public class FMSMQConnectionFactory {

    @ConfigProperty(name = "ibm.mq.host")
    String host;
    @ConfigProperty(name = "ibm.mq.port")
    int port;
    @ConfigProperty(name = "ibm.mq.channel")
    String channel;
    @ConfigProperty(name = "ibm.mq.queue-manager-name")
    String queueManagerName;
    @ConfigProperty(name = "ibm.mq.user")
    String user;
    @ConfigProperty(name = "ibm.mq.password")
    String password;

    @Inject
    FMSLogger fmsLogger;

    /**
     * This method will return connectionFactory object
     * from provided MQ details
     * @return  ConnectionFactory object
     * @throws Exception
     */
    @Produces
    public ConnectionFactory connectionFactory() {
      MQConnectionFactory factory = new MQConnectionFactory();
        try {
            factory.setHostName(host);
            factory.setPort(port);
            factory.setChannel(channel);
            factory.setTransportType(WMQConstants.WMQ_CM_CLIENT);
            factory.setStringProperty(WMQConstants.USERID, user);
            factory.setStringProperty(WMQConstants.PASSWORD, password);
            factory.setQueueManager(queueManagerName);
		} catch (Exception e ) {
			fmsLogger.error("Exception while creating Factory class",e);
		} 
        return factory;
    }
}

