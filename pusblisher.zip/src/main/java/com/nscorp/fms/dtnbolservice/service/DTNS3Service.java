package com.nscorp.fms.dtnbolservice.service;

import org.eclipse.microprofile.config.inject.ConfigProperty;

import com.nscorp.fms.logging.exception.FMSException;
import com.nscorp.fms.logging.logger.FMSLogger;
import com.nscorp.fms.logging.model.TracePoint;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.DeleteObjectRequest;
import software.amazon.awssdk.services.s3.model.S3Exception;

/**
 * Service responsible for interacting with Amazon S3.
 * It provides functionality to write failed records, upload files, and delete
 * processed objects from the configured S3 bucket.
 */
@ApplicationScoped
public class DTNS3Service{

    @ConfigProperty(name = "app.s3.failedPrefix")
    String failedPrefix;

    @ConfigProperty(name = "app.s3.arn")
    String bucket;
    
    @ConfigProperty(name = "app.s3.inputPrefix")
    String inputPrefix;

    @Inject
    S3Client s3Client;

    @Inject
    S3ObjectHandlerService s3ObjectHandlerService;

    @Inject
    S3FileHandlerService s3FileHandlerService;
    
    @Inject
    FMSLogger fmsLogger;

    /**
     * Writes a specific DTN BOL record (typically a failure) to the S3 bucket 
     * using the configured failed prefix.
     * 
     * @param fileName The name of the file associated with the record.
     * @param dtnBolRecord The record content to be stored.
     * @throws FMSException If an error occurs during the S3 operation.
     */
    public void write(String fileName, String dtnBolRecord) throws FMSException {
        s3ObjectHandlerService.processRecord(s3Client,bucket,failedPrefix,fileName,dtnBolRecord);

    }

    /**
     * Uploads a raw byte array as a file to the configured S3 bucket.
     * 
     * @param fileName The destination name for the file in S3.
     * @param csvFileBytes The file content in bytes.
     * @return true if the upload was successful, false otherwise.
     * @throws FMSException If an error occurs during the upload process.
     */
    public boolean upload(String fileName, byte[] csvFileBytes) throws FMSException {
        return s3FileHandlerService.uploadFile(s3Client,bucket,fileName,csvFileBytes);
    }


    /**
     * Deletes a file from the S3 bucket after processing.
     * The method targets objects with a suffix of "_Processing" within the input prefix.
     * 
     * @param fileName The base name of the file to delete.
     * @throws FMSException If a specific S3 exception or general error occurs during deletion.
     */
    public void deleteFile(String fileName) throws FMSException {
    	String objectKey = inputPrefix+"/" + fileName +"_Processing";
    	fmsLogger.info(String.format("DTNA Publisher :Deleting File from S3   %s ", fileName), TracePoint.IN_PROCESS); 
        
        DeleteObjectRequest deleteRequest = DeleteObjectRequest.builder()
                .bucket(bucket)
                .key(objectKey)
                .build();

        try {
			s3Client.deleteObject(deleteRequest);
			fmsLogger.info(String.format("DTNA Publisher :Deleted File from S3   %s ", fileName), TracePoint.IN_PROCESS); 
		} catch (S3Exception e) {
			throw new FMSException(e.getMessage(), e);
		} catch (Exception e) {
			throw new FMSException(e.getMessage(), e);
		} 
    }
}
