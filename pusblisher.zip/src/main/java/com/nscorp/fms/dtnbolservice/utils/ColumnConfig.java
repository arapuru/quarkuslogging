package com.nscorp.fms.dtnbolservice.utils;

/**
 * Data model representing the configuration of a specific CSV column.
 * It defines the mapping metadata, including position, naming, data type, 
 * and validation requirements used during the CSV parsing and JSON conversion process.
 */
public class ColumnConfig {

	private String column;
	private int index;
	private boolean required;
	private String dataType;
	
	/**
	 * Gets the name of the column.
	 * @return The column name.
	 */
	public String getColumn() {
		return column;
	}

	/**
	 * Sets the name of the column.
	 * @param column The column name to set.
	 */
	public void setColumn(String column) {
		this.column = column;
	}

	/**
	 * Gets the zero-based index of the column in the CSV file.
	 * @return The column index.
	 */
	public int getIndex() {
		return index;
	}

	/**
	 * Sets the zero-based index of the column.
	 * @param index The column index to set.
	 */
	public void setIndex(int index) {
		this.index = index;
	}

	/**
	 * Checks if the column is a required field.
	 * @return true if the column is required, false otherwise.
	 */
	public boolean isRequired() {
		return required;
	}

	/**
	 * Sets whether the column is a required field.
	 * @param required The requirement status to set.
	 */
	public void setRequired(boolean required) {
		this.required = required;
	}

	/**
	 * Gets the expected data type of the column's value (e.g., String, Number).
	 * @return The data type name.
	 */
	public String getDataType() {
		return dataType;
	}

	/**
	 * Sets the expected data type of the column's value.
	 * @param dataType The data type to set.
	 */
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
}
