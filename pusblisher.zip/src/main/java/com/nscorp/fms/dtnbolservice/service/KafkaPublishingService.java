package com.nscorp.fms.dtnbolservice.service;

import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;

import org.apache.kafka.common.header.internals.RecordHeaders;
import org.eclipse.microprofile.faulttolerance.Retry;
import org.eclipse.microprofile.reactive.messaging.Channel;
import org.eclipse.microprofile.reactive.messaging.Emitter;
import org.eclipse.microprofile.reactive.messaging.Message;

import com.nscorp.fms.logging.exception.FMSException;
import com.nscorp.fms.logging.logger.FMSLogger;
import com.nscorp.fms.logging.model.TracePoint;

import io.smallrye.reactive.messaging.kafka.KafkaRecord;
import io.smallrye.reactive.messaging.kafka.api.OutgoingKafkaRecordMetadata;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.json.Json;
import jakarta.json.JsonObject;
import jakarta.json.JsonReader;

/**
 * Service class responsible for publishing DTN Bill of Lading (BOL) records to a Kafka topic.
 * It handles JSON extraction, metadata attachment (headers, keys), and asynchronous 
 * message delivery with retry logic.
 */
@ApplicationScoped
public class KafkaPublishingService {

	@Inject
	@Channel("kafka-producer")
	Emitter<String> emitter;

	@Inject
	FMSLogger fmsLogger;

	public static final String HEADER_PUBLISHING_TIMESTAMP = "publishing-timestamp";
	public static final String CORRELATION_ID = "CORRELATION_ID";

	public static final DateTimeFormatter TIMESTAMP_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss")
			.withZone(ZoneOffset.UTC);

	/**
	 * Prepares and initiates the publishing of a DTN BOL record to Kafka.
	 * Extracts the BOL number for use as the Kafka message key and attaches correlation metadata.
	 * 
	 * @param dtnBolRecord The JSON string representation of the BOL record.
	 * @param correlationId Unique identifier for tracing the request across services.
	 * @return A CompletionStage indicating the eventual success (true) or failure of the publish operation.
	 */
	public CompletionStage<Boolean> publish(String dtnBolRecord, String correlationId) {
		String bolNumber = extractBolNumber(dtnBolRecord);
		fmsLogger.info(String.format("%s : Publishing DTN with BolNumber %s  with correlation Id  %s",
				TracePoint.IN_PROCESS.name(), bolNumber, correlationId), TracePoint.IN_PROCESS);
		try {
			RecordHeaders headers = new RecordHeaders();
			String publishingTimestamp = TIMESTAMP_FORMATTER.format(Instant.now());
			headers.add(HEADER_PUBLISHING_TIMESTAMP, publishingTimestamp.getBytes(StandardCharsets.UTF_8));
			headers.add(CORRELATION_ID, correlationId.getBytes(StandardCharsets.UTF_8));
			OutgoingKafkaRecordMetadata<String> metadata = OutgoingKafkaRecordMetadata.<String>builder()
					.withHeaders(headers).withKey(bolNumber).build();
			
			Message<String> message = KafkaRecord.of (bolNumber, dtnBolRecord).addMetadata(metadata);

			return sendToKafka(message);
		} catch (Exception e) {
			fmsLogger.error("Exception during while publishing data to Kafka", e);
			return CompletableFuture.failedStage(new FMSException(e.getMessage(), e));

		}
	}

	/**
	 * Sends a reactive Message to the Kafka emitter with configured retry logic.
	 * Uses manual acknowledgment (Ack/Nack) to resolve the returned CompletionStage.
	 * 
	 * @param msg The Reactive Messaging Message containing the payload and Kafka metadata.
	 * @return A CompletionStage that completes true on Ack, or completes exceptionally on Nack.
	 */
	@Retry(maxRetries = 4, delay = 500)
	public CompletionStage<Boolean> sendToKafka(Message<String> msg) {
		CompletableFuture<Boolean> result = new CompletableFuture<>();
		msg = msg.withAck(() -> {
			result.complete(true);
			return CompletableFuture.completedFuture(null);
		}).withNack(failure -> {
			result.completeExceptionally(failure);
			return CompletableFuture.completedFuture(null);
		});

		emitter.send(msg);
		return result;
	}

	/**
	 * Parses the BOL JSON payload to extract the "bol_number" field.
	 * 
	 * @param dtnBolRecord The JSON string.
	 * @return The bol_number value if found; otherwise an empty string.
	 */
	private String extractBolNumber(String dtnBolRecord) {
	    if (dtnBolRecord == null || dtnBolRecord.isBlank()) {
	        return "";
	    }
	    try (JsonReader reader = Json.createReader(new StringReader(dtnBolRecord))) {
	        JsonObject jsonObject = reader.readObject();
	        return jsonObject.getString("bol_number", "");
	        
	    } catch (Exception e) {
	        fmsLogger.error("Failed to parse bol_number from payload", e);
	        return "";
	    }
	}

}
