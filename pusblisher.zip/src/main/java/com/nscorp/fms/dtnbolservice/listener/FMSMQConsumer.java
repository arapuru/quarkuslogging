package com.nscorp.fms.dtnbolservice.listener;

import com.nscorp.fms.dtnbolservice.processor.DTNBolProcessor;
import com.nscorp.fms.logging.logger.FMSLogger;

import com.nscorp.fms.logging.model.TracePoint;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.util.Optional;

import org.eclipse.microprofile.reactive.messaging.Incoming;
import io.smallrye.reactive.messaging.jms.IncomingJmsMessageMetadata;

/**
 * This class is meant for connecting MQ Listener channel
 * and consume MQ messages
 * 
 */
@ApplicationScoped
public class FMSMQConsumer {

    @Inject
    DTNBolProcessor dtnBolProcessor;

    @Inject
    FMSLogger fmsLogger;

    /**
     * This method will consume messages coming
     * from IBM queue
     * @param message message coming from IBM MQ queue
     */
    @Incoming("mq-listener-channel")
    public void consume(String message,  Optional<IncomingJmsMessageMetadata> metadata) {
        String messageId = metadata.isPresent() ? metadata.get().getMessageId():"";

        fmsLogger.info(String.format("DTNA Publisher : Received MQ Message  %s  With Message Id %s", message, messageId), TracePoint.START);
        dtnBolProcessor.process(message,messageId);

    }
}
