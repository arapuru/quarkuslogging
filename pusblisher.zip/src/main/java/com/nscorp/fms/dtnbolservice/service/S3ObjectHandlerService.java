package com.nscorp.fms.dtnbolservice.service;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import com.nscorp.fms.logging.exception.FMSException;
import com.nscorp.fms.logging.logger.FMSLogger;
import com.nscorp.fms.logging.model.TracePoint;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import software.amazon.awssdk.core.ResponseInputStream;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.GetObjectResponse;
import software.amazon.awssdk.services.s3.model.HeadObjectRequest;
import software.amazon.awssdk.services.s3.model.NoSuchKeyException;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;
import software.amazon.awssdk.services.s3.model.PutObjectResponse;
import software.amazon.awssdk.utils.IoUtils;

/**
 * Service class for handling S3 object-level content manipulations.
 * Provides functionality to append data to existing S3 objects or create new ones,
 * specifically used for logging failed DTN BOL records into date-partitioned CSV files.
 */
@ApplicationScoped
public class S3ObjectHandlerService {
	
	@Inject
	FMSLogger fmsLogger;

    /**
     * Processes a single failure record by appending it to a daily-partitioned CSV file in S3.
     * If the file exists, it retrieves the content and appends the new record; otherwise, 
     * it creates a new file.
     * 
     * @param s3Client The AWS S3 client instance.
     * @param bucketName The name/ARN of the target S3 bucket.
     * @param prefix The S3 key prefix (folder path) for failed records.
     * @param fileName The original filename to associate with the failure.
     * @param newRecord The new CSV record string to be added.
     * @throws FMSException If an error occurs during reading from or writing to S3.
     */
    public void processRecord(S3Client s3Client, String bucketName,String prefix, String fileName, String newRecord) throws FMSException{
    	try {
    		
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			String datePrefix = LocalDate.now().format(formatter);
			String objectKey = prefix+ "/" + datePrefix + "/" + fileName + "_failed.csv";
			fmsLogger.info(String.format("DTNA Publisher : Updating Failed CSV record :%s in S3 Bucket :  %s  in Path  : %s", fileName, bucketName,objectKey), TracePoint.IN_PROCESS);

			String existingContent = "";

			// Check if the objectKey exists, get content if it does
			if (objectExists(s3Client,objectKey,bucketName)) {
			    existingContent = getObjectContent(s3Client,objectKey,bucketName);
			}

			// Append the new record
			String updatedContent = existingContent + System.lineSeparator() +newRecord ;
			
			// Upload the updated content (overwrites or creates new)
			uploadObject(s3Client,objectKey, updatedContent,bucketName);
			fmsLogger.info(String.format("DTNA Publisher : Updating Failed CSV record Completed :%s in S3 Bucket :  %s  in Path  : %s", fileName, bucketName,objectKey), TracePoint.IN_PROCESS);
		} catch (FMSException e) {
			throw new FMSException(e.getMessage(), e);
		}
    }

    /**
     * Checks if an object exists in the specified S3 bucket.
     * 
     * @param s3Client The AWS S3 client instance.
     * @param objectKey The specific path/key of the object.
     * @param bucketName The name of the bucket.
     * @return {@code true} if the object exists.
     * @throws FMSException If a non-404 error occurs during the head request.
     */
    private boolean objectExists(S3Client s3Client, String objectKey, String bucketName)  throws FMSException{
        try {
            // The bucketArn is used directly as the bucket identifier
            HeadObjectRequest headObjectRequest = HeadObjectRequest.builder().bucket(bucketName).key(objectKey).build();
            s3Client.headObject(headObjectRequest);
            return true;
        } catch (Exception e) {
        	fmsLogger.debug(String.format("DTNA Publisher :  Failed CSV File doesn't existing in given  bucket :%s  in Path  : %s", bucketName,objectKey), TracePoint.IN_PROCESS);
        	return false;
        }
    }

    /**
     * Retrieves the body of an S3 object as a UTF-8 string.
     * 
     * @param s3Client The AWS S3 client instance.
     * @param objectKey The specific path/key of the object.
     * @param bucketName The name of the bucket.
     * @return The object content as a String.
     * @throws UncheckedIOException If an I/O error occurs while reading the response stream.
     */
    private String getObjectContent(S3Client s3Client,String objectKey, String bucketName) {
        // The bucketArn is used directly as the bucket identifier
        GetObjectRequest getObjectRequest = GetObjectRequest.builder().bucket(bucketName).key(objectKey).build();

        try (ResponseInputStream<GetObjectResponse> response = s3Client.getObject(getObjectRequest)) {
            return IoUtils.toUtf8String(response);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    /**
     * Uploads string content to an S3 object with text/csv content type.
     * 
     * @param s3Client The AWS S3 client instance.
     * @param objectKey The target path/key in S3.
     * @param content The string content to upload.
     * @param bucketName The name of the bucket.
     * @throws FMSException If the upload fails.
     */
    private void uploadObject(S3Client s3Client, String objectKey, String content, String bucketName) throws FMSException {
        PutObjectRequest putObjectRequest = PutObjectRequest.builder()
                .bucket(bucketName)
                .key(objectKey)
                .contentType("text/csv")
                .build();

        PutObjectResponse putObjectResponse =   s3Client.putObject(putObjectRequest, RequestBody.fromString(content));
        if(putObjectResponse.eTag()!=null) {
        	fmsLogger.debug(String.format("DTNA Publisher : Updating  CSV record Completed in S3 Bucket  :  %s  in Path  : %s with Etag : %s ", bucketName,objectKey, putObjectResponse.eTag()), TracePoint.IN_PROCESS);
        }
    }
}
