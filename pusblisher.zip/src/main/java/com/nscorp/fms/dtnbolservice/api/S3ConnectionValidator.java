package com.nscorp.fms.dtnbolservice.api;

import com.nscorp.fms.logging.logger.FMSLogger;

import io.quarkus.runtime.StartupEvent;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.event.Observes;
import jakarta.inject.Inject;
import software.amazon.awssdk.services.s3.S3Client;

@ApplicationScoped
public class S3ConnectionValidator {

    @Inject
    FMSLogger fmsLogger;

    @Inject
    S3Client s3Client;

    void onStart(@Observes StartupEvent ev) {               
        try {
        	fmsLogger.info("Connecting S3");
        	
            // Attempt to list buckets to validate the connection
            //ListBucketsResponse response = s3Client.listBuckets();
            //fmsLogger.info("S3 Connection validated" + response.buckets());
        } catch (Exception e) {
        	fmsLogger.error("Failed to connect to S3 on startup!", e);
            // Optionally throw a RuntimeException to halt application startup
            throw new RuntimeException("S3 validation failed", e);
        }
    }
}
