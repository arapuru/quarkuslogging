package com.nscorp.fms.dtnbolservice.api;

import java.util.UUID;

import com.nscorp.fms.dtnbolservice.processor.DTNBolProcessor;
import com.nscorp.fms.logging.logger.FMSLogger;

import jakarta.inject.Inject;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;


@Path("/hello")
public class DTNPublisherResource {

    @Inject
    FMSLogger fmsLogger;

   @Inject 
   DTNBolProcessor dtnBolProcessor;

    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String hello() {
        return "Hello from Quarkus REST 01";
    }

    @GET
    @Produces(MediaType.TEXT_PLAIN)
    @Path("/publish")
    public String publish() {
        try {
        	
        	dtnBolProcessor.process("dailymessages.CSV;/outbound_s4", "ID :"+UUID.randomUUID().toString());
        	
			
            //dtns3Service.upload("dailymessages",content);
            //System.out.println("content length "+content.length);
		} catch (Exception e) {
			e.printStackTrace();
		}

        return "Hello from Quarkus REST 01";
    }

   
}
