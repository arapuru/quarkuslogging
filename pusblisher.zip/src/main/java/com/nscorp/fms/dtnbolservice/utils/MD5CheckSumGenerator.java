package com.nscorp.fms.dtnbolservice.utils;

import java.security.MessageDigest;

import com.nscorp.fms.logging.exception.FMSException;

import jakarta.enterprise.context.ApplicationScoped;

/**
 * Utility class for generating MD5 checksums.
 * This service provides a mechanism to compute a hexadecimal hash of a byte array,
 * primarily used for verifying file integrity and detecting duplicate uploads in S3.
 */
@ApplicationScoped
public class MD5CheckSumGenerator {

    /**
     * Computes the MD5 hash of the provided byte array and returns it as a hexadecimal string.
     * 
     * @param bytes The raw byte array to be hashed.
     * @return A hexadecimal string representation of the MD5 checksum.
     * @throws FMSException If the MD5 algorithm is unavailable or an error occurs during hashing.
     */
    public String getMD5Checksum(byte[] bytes) throws FMSException{
        try {
            // Get an MD5 MessageDigest instance
            MessageDigest md = MessageDigest.getInstance("MD5");
            // Compute the MD5 hash
            byte[] hash = md.digest(bytes);

            // Convert the byte array to a hexadecimal string
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) {
                // The "%02x" format specifier ensures each byte is represented by two hexadecimal characters
                sb.append(String.format("%02x", b));
            }
            return sb.toString();

        } catch (Exception e) {
            throw new FMSException(e.getMessage() ,e);
        }
    }

}
