package com.nscorp.fms.dtnbolservice.service;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.SftpException;
import com.nscorp.fms.logging.exception.FMSException;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.apache.commons.io.IOUtils;

import java.io.InputStream;

/**
 * Service class responsible for downloading CSV files from a remote SFTP server.
 * It manages the SFTP channel lifecycle by opening a connection through the 
 * SFTPSessionService and ensuring it is closed after the transfer.
 */
@ApplicationScoped
public class SFTPCSVDownloadService {

	@Inject
	SFTPSessionService sessionService;

	/**
	 * Downloads a file from the specified remote SFTP path and returns its content as a byte array.
	 * 
	 * @param remotePath The full path to the file on the SFTP server.
	 * @return A byte array containing the file's raw data.
	 * @throws FMSException If an SFTP protocol error occurs or the file cannot be read.
	 */
	public byte[] downloadCsvAsBytes(String remotePath) throws FMSException {
		ChannelSftp sftp = null;
		byte[] csvBytes = null;
		try {
			sftp = sessionService.openChannel();
			try (InputStream inputStream = sftp.get(remotePath)) {
				csvBytes = IOUtils.toByteArray(inputStream);
			}
		} catch (SftpException e) {
			throw new FMSException("SFTP error for path: " + remotePath + " - " + e.getMessage(), e);
		} catch (Exception e) {
			throw new FMSException("Failed to download file from SFTP: " + e.getMessage(), e);
		} finally {
			sessionService.close(sftp);
		}
		return csvBytes;
	}
}
