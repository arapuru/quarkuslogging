package com.nscorp.fms.dtnbolservice.service;

import java.io.InputStream;
import java.util.List;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nscorp.fms.dtnbolservice.utils.ColumnConfig;

import jakarta.enterprise.context.ApplicationScoped;

/**
 * Service class responsible for reading and parsing the CSV schema configuration.
 * It loads the column definitions from a JSON resource file to guide the 
 * CSV-to-JSON transformation process.
 */
@ApplicationScoped
public class SchemaReaderService {

	ObjectMapper objectMapper;

	/**
	 * Reads the "schema.json" file from the classpath resources and maps it 
	 * to a list of ColumnConfig objects.
	 * 
	 * @return A List of {@link ColumnConfig} representing the expected CSV structure.
	 * @throws RuntimeException If the schema file is missing or if an error occurs during JSON parsing.
	 */
	public List<ColumnConfig> getColumns() {
		ObjectMapper objectMapper = new ObjectMapper();
		try (InputStream inputStream = Thread.currentThread().getContextClassLoader()
				.getResourceAsStream("schema.json")) {
			if (inputStream == null) {
				throw new RuntimeException("File not found in resources");
			}
			return objectMapper.readValue(inputStream, new TypeReference<List<ColumnConfig>>() {
			});
		} catch (Exception e) {
			throw new RuntimeException("Error reading JSON", e);
		}
	}

}
