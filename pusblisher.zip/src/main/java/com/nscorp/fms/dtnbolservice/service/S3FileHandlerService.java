package com.nscorp.fms.dtnbolservice.service;

import org.eclipse.microprofile.config.inject.ConfigProperty;

import com.nscorp.fms.dtnbolservice.utils.MD5CheckSumGenerator;
import com.nscorp.fms.logging.exception.FMSException;
import com.nscorp.fms.logging.logger.FMSLogger;
import com.nscorp.fms.logging.model.TracePoint;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.HeadObjectRequest;
import software.amazon.awssdk.services.s3.model.HeadObjectResponse;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;
import software.amazon.awssdk.services.s3.model.PutObjectResponse;

/**
 * Service class for handling file-level operations with Amazon S3.
 * It provides methods to upload CSV files and verify their existence using MD5 checksums 
 * to prevent duplicate processing.
 */
@ApplicationScoped
public class S3FileHandlerService {

	@ConfigProperty(name = "app.s3.inputPrefix")
	String inputPrefix;

	@Inject
	MD5CheckSumGenerator md5CheckSumGenerator;

	@Inject
	FMSLogger fmsLogger;

	/**
	 * Uploads a CSV file to the specified S3 bucket and path.
	 * Before uploading, it checks if a file with the same MD5 checksum already exists 
	 * at the target location to avoid redundant uploads.
	 * 
	 * @param s3Client The AWS S3 client instance.
	 * @param bucket The name of the S3 bucket.
	 * @param fileName The name of the file to be uploaded.
	 * @param csvFileBytes The content of the file in bytes.
	 * @return {@code true} if the file was successfully uploaded; {@code false} if the file already exists or upload failed.
	 * @throws FMSException If an error occurs during the S3 communication or MD5 generation.
	 */
	public boolean uploadFile(S3Client s3Client, String bucket, String fileName, byte[] csvFileBytes)
			throws FMSException {

		String objectKey = inputPrefix + "/" + fileName + "_Processing";
		fmsLogger.info(String.format("DTNA Publisher : Uploading File :%s in S3 Bucket :  %s  in Path  : %s", fileName,
				bucket, objectKey), TracePoint.IN_PROCESS);
		try {
			boolean fileExists = doesFileExistWithMd5(s3Client, bucket, objectKey, csvFileBytes);
			if (fileExists) {
				fmsLogger
						.info(String.format("DTNA Publisher : File with Object Key already Exists :  %s  in Path  : %s",
								fileName, bucket, objectKey), TracePoint.IN_PROCESS);
				return false;
			} else {
				PutObjectRequest putObjectRequest = PutObjectRequest.builder().bucket(bucket).key(objectKey)
						.contentType("text/csv").contentLength((long) csvFileBytes.length) // Set content length
						.build();
				PutObjectResponse putObjectResponse = s3Client.putObject(putObjectRequest,
						RequestBody.fromBytes(csvFileBytes));
				if (putObjectResponse.eTag() != null) {
					fmsLogger.info(String.format("DTNA Publisher : Uploaded File :%s in S3 Bucket :  %s  in Path  : %s",
							fileName, bucket, objectKey), TracePoint.IN_PROCESS);
					return true;
				} else {
					return false;
				}
			}
		} catch (Exception e) {
			throw new FMSException(e.getMessage(), e);
		}

	}

	/**
	 * Checks if a file exists in S3 and matches the local MD5 checksum.
	 * It retrieves the ETag from S3 metadata and compares it against the locally generated checksum.
	 * 
	 * @param s3Client The AWS S3 client instance.
	 * @param bucket The name of the S3 bucket.
	 * @param key The object key (path) in S3.
	 * @param csvFileBytes The local file content to generate a checksum for comparison.
	 * @return {@code true} if the remote file exists and its ETag matches the local MD5; {@code false} otherwise.
	 * @throws FMSException If an error occurs during metadata retrieval or checksum calculation.
	 */
	public boolean doesFileExistWithMd5(S3Client s3Client, String bucket, String key, byte[] csvFileBytes)
			throws FMSException {
		// 1. Calculate Local MD5
		String localMd5 = md5CheckSumGenerator.getMD5Checksum(csvFileBytes);

		try {
			// 2. Get S3 Object Metadata
			HeadObjectRequest headObjectRequest = HeadObjectRequest.builder().bucket(bucket).key(key).build();
			HeadObjectResponse metadata = s3Client.headObject(headObjectRequest);

			// 3. Compare ETag (Note: S3 ETags are wrapped in quotes)
			String s3ETag = metadata.eTag().replace("\"", "");
			return localMd5.equals(s3ETag);

		} catch (Exception e) {
			fmsLogger.info(String.format("DTNA Publisher : File Not Exist in S3 Bucket :  %s  in Path  : %s",
					bucket, key), TracePoint.IN_PROCESS);
			return false;
		}
	}
}