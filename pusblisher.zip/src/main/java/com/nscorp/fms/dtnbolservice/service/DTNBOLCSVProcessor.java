package com.nscorp.fms.dtnbolservice.service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CompletionStage;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;
import org.eclipse.microprofile.config.inject.ConfigProperty;

import com.nscorp.fms.dtnbolservice.utils.ColumnConfig;
import com.nscorp.fms.logging.exception.FMSException;
import com.nscorp.fms.logging.logger.FMSLogger;
import com.nscorp.fms.logging.model.TracePoint;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.json.Json;
import jakarta.json.JsonObject;
import jakarta.json.JsonObjectBuilder;

/**
 * Service class responsible for processing DTN Bill of Lading (BOL) CSV data.
 * It parses CSV records, validates them against configured sizes, converts valid records 
 * to JSON format for Kafka publication, and uploads failed records to an S3 bucket.
 */
@ApplicationScoped
public class DTNBOLCSVProcessor {

    @Inject
    SchemaReaderService schemaReaderService;
    
    @Inject
    KafkaPublishingService kafkaPublishingService;
    
    @Inject 
    DTNS3Service dtns3Service;
    
    @Inject
    FMSLogger fmsLogger;
    
    @ConfigProperty(name = "dtn.record.size")
    Integer recordSize;

    /**
     * Processes the provided CSV byte array by parsing records and publishing them to Kafka.
     * Records that are malformed or fail to publish are collected and uploaded to S3.
     * 
     * @param csvBytes The raw byte array of the CSV file.
     * @param messageId Unique identifier for the message tracking.
     * @param fileName The name of the file being processed, used for logging and S3 storage.
     * @throws FMSException If an error occurs during parsing or processing.
     */
    public void process(byte[] csvBytes, String messageId, String fileName) throws FMSException {
    	fmsLogger.info(String.format("DTNA Publisher :Processing  csv data of filename :  %s ", fileName), TracePoint.IN_PROCESS); 
        List<CSVRecord> failedRecords = new ArrayList<>();
        
        try(Reader reader = new InputStreamReader(new ByteArrayInputStream(csvBytes), StandardCharsets.UTF_8);
                 CSVParser parser = CSVFormat.DEFAULT.withTrim().parse(reader)) {
            
            List<ColumnConfig> columnConfigs = schemaReaderService.getColumns();
            List<String> headers = new ArrayList<>();
            for (ColumnConfig columnConfig : columnConfigs) {
                headers.add(columnConfig.getColumn());
            }

            Iterator<CSVRecord> iterator = parser.iterator();
             
            while (iterator.hasNext()) {
                CSVRecord record = iterator.next();
                
                if (record == null || record.size() != recordSize) {
                	fmsLogger.debug(String.format("DTNA Publisher :Record size :%d and configured  Record Size:  %d ",  record.size(),recordSize), TracePoint.IN_PROCESS);
                	fmsLogger.debug("Malformed or empty record found, adding to failure list", TracePoint.IN_PROCESS); 
                    failedRecords.add(record);
                    continue;
                }
               
                // Build JSON using Jakarta API
                JsonObject jsonObject = getJsonObject(headers, record);
                String json = jsonObject.toString();
                
                CompletionStage<Boolean> publishStatus = kafkaPublishingService.publish(json, messageId);
                publishStatus.thenAccept(isPublished -> {
                    if (isPublished) {
                        fmsLogger.debug("Published DTN Successfully");
                    } else {
                        failedRecords.add(record);
                    }
                });
            }
            fmsLogger.info(String.format("DTNA Publisher :Found %d Failed Records upload to S3 ", failedRecords.size()), TracePoint.IN_PROCESS); 
            uploadFailuresToS3(fileName, failedRecords);
            fmsLogger.info(String.format("DTNA Publisher :Processing  csv data of filename :  %s is completed ", fileName), TracePoint.IN_PROCESS);   
        } catch (Exception e) {
             throw new FMSException(e.getMessage(), e);
        }
    }

    /**
     * Builds a Jakarta JsonObject from the CSV record using the provided headers.
     * 
     * @param headers List of column names to be used as JSON keys.
     * @param record The CSV record containing the values.
     * @return A JsonObject representation of the CSV record.
     */
    private JsonObject getJsonObject(List<String> headers, CSVRecord record) {
        JsonObjectBuilder builder = Json.createObjectBuilder();
        fmsLogger.debug(String.format("DTNA Publisher :getJsonObject Header size :%d and configured  Record Size:  %d ",  headers.size(),record.size()), TracePoint.IN_PROCESS);
        // Use the smaller of the two sizes to prevent IndexOutOfBounds
        int columnsToProcess = Math.min(headers.size(), record.size());
        
        for (int i = 0; i < columnsToProcess; i++) {
            String header = headers.get(i);
            String value = record.get(i);
            builder.add(header, value != null ? value : "");
        }
        return builder.build();
    }

    /**
     * Serializes failed CSV records into a string and uploads them to S3.
     * 
     * @param fileName The original file name used to identify the failure log.
     * @param failedRecords List of records that failed validation or publication.
     * @throws IOException If an error occurs during CSV printing or S3 writing.
     */
    private void uploadFailuresToS3(String fileName, List<CSVRecord> failedRecords) throws IOException {
        if (failedRecords != null && !failedRecords.isEmpty()) {
            StringWriter sw = new StringWriter();
            try (CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT)) {
                for (CSVRecord record : failedRecords) {
                    printer.printRecord(record);
                }
            }
            dtns3Service.write(fileName, sw.toString());
        }
    }
}
