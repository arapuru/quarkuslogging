package com.nscorp.fms.dtnbolservice.service;

import java.io.IOException;
import java.util.Properties;

import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.eclipse.microprofile.faulttolerance.Retry;
import org.eclipse.microprofile.faulttolerance.Timeout;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

import jakarta.enterprise.context.ApplicationScoped;

/**
 * Service responsible for managing SFTP sessions and channels using the JSch library.
 * It handles the lifecycle of connections to the GlobalScape SFTP server, including
 * authentication, connection timeouts, and safe resource disposal.
 */
@ApplicationScoped
public class SFTPSessionService {

	@ConfigProperty(name = "globalscape.host")
	String host;

	@ConfigProperty(name = "globalscape.port")
	int port;

	@ConfigProperty(name = "globalscape.username")
	String username;

	@ConfigProperty(name = "globalscape.password")
	String password;

	@ConfigProperty(name = "globalscape.session.timeout")
	Integer sessionTimeout;

	@ConfigProperty(name = "globalscape.channel.timeout")
	Integer channelTimeout;

	@ConfigProperty(name = "globalscape.server.host.key")
	String serverHostKey;

	/**
	 * Opens and connects an SFTP channel to the configured host.
	 * This method includes fault tolerance with retries for transient IO or connection issues,
	 * while aborting immediately on SFTP-specific logic errors.
	 * 
	 * @return A connected {@link ChannelSftp} ready for file operations.
	 * @throws Exception If connection fails after the maximum number of retries or times out.
	 */
	@Retry(maxRetries = 3, delay = 1000, jitter = 250, 
			retryOn = { IOException.class, JSchException.class }, 
			abortOn = { SftpException.class }
	)
	@Timeout(10000)
	public ChannelSftp openChannel() throws Exception {
		JSch jsch = new JSch();
		Session session = jsch.getSession(username, host, port);
		session.setPassword(password);

		Properties config = new Properties();
		config.put("StrictHostKeyChecking", "no");
		config.put("server_host_key", serverHostKey);
		session.setConfig(config);

		session.connect(sessionTimeout);
		Channel channel = session.openChannel("sftp");
		channel.connect(channelTimeout);

		return (ChannelSftp) channel;
	}


	/**
	 * Safely closes the SFTP channel and its associated session.
	 * 
	 * @param sftp The {@link ChannelSftp} to be closed. If null, the method returns silently.
	 */
	public void close(ChannelSftp sftp) {
		if (sftp == null)
			return;
		try {
			Session session = sftp.getSession();
			sftp.exit();

			if (session != null) {
				session.disconnect();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
