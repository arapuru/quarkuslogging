REM Run this batch file inside of a Visual Studio 2022 Native Tools Command Prompt 
REM https://aka.ms/vs/17/release/vs_buildtools.exe
REM Install C++ Build Tools
REM Launch the Native Tools Command Prompt from the Start Menu

./gradlew build -Dquarkus.native.enabled=true -Dquarkus.package.jar.enabled=false