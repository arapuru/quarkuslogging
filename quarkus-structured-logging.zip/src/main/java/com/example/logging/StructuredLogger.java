
package com.example.logging;

import io.opentelemetry.api.trace.Span;
import org.jboss.logging.Logger;

public class StructuredLogger {

    private static final Logger LOG = Logger.getLogger("STRUCTURED");

    public static void info(AppLog log) {
        Span span = Span.current();
        if (span != null && span.getSpanContext().isValid()) {
            log.trace_id = span.getSpanContext().getTraceId();
            log.span_id = span.getSpanContext().getSpanId();
        }
        LOG.info(new AppLogArgument(log));
    }
}
