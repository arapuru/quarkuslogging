
package com.example.logging;

public class LogError {
    public String code;
    public String message;
}
