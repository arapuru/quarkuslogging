
package com.example.logging;

import io.quarkiverse.loggingjson.JsonGenerator;
import io.quarkiverse.loggingjson.providers.StructuredArgument;
import java.io.IOException;

public class AppLogArgument implements StructuredArgument {

    private final AppLog log;

    public AppLogArgument(AppLog log) {
        this.log = log;
    }

    @Override
    public String key() {
        return null;
    }

    @Override
    public void writeTo(JsonGenerator jg) throws IOException {
        jg.writeStartObject();
        jg.writeStringField("correlation_id", log.correlation_id);
        jg.writeStringField("environment", log.environment);
        jg.writeStringField("service", log.service);
        jg.writeStringField("tracepoint", log.tracepoint);
        if (log.details != null) jg.writeObjectField("details", log.details);
        if (log.payload != null) jg.writeStringField("payload", log.payload);
        if (log.error != null) jg.writeObjectField("error", log.error);
        if (log.metrics != null) jg.writeObjectField("metrics", log.metrics);
        jg.writeStringField("trace_id", log.trace_id);
        jg.writeStringField("span_id", log.span_id);
        jg.writeEndObject();
    }
}
