
package com.example.logging;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import java.util.Map;

@Path("/test")
public class TestResource {

    @GET
    public String test() {
        AppLog log = new AppLog();
        log.correlation_id = "cid-001";
        log.environment = "prod";
        log.service = "demo-service";
        log.tracepoint = "GET /test";
        log.details = Map.of("key", "value");
        log.payload = "hello";
        log.metrics = new LogMetrics();
        log.metrics.duration_ms = 12;
        log.metrics.count = 1;

        StructuredLogger.info(log);
        return "OK";
    }
}
