
package com.example.logging;

public class LogMetrics {
    public long duration_ms;
    public int count;
}
