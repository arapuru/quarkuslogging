
package com.example.logging;

import java.util.Map;

public class AppLog {
    public String correlation_id;
    public String environment;
    public String service;
    public String tracepoint;
    public Map<String, Object> details;
    public String payload;
    public LogError error;
    public LogMetrics metrics;
    public String trace_id;
    public String span_id;
}
